package com.github.Unbearables.kuchyn.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.github.Unbearables.kuchyn.main.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Sklad;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class NewSkladController
{
	@FXML private AnchorPane skladNovyPane;
	@FXML private TextField nazevSurovina;
	@FXML private TextField mnozstviSuroviny;
	@FXML private Label errorNazevSurovina;
	@FXML private Label errorUdaje;
	
	private List<String> surovinyRecept;
	private FileManager fileManager = Start.fileManager;
	
	private JSONObject sklad;
	
	public void initialize() 
	{
		errorNazevSurovina.setText(null);
		errorUdaje.setText(null);
		sklad = new JSONObject();
	}
	
	public void pridejSurovinu() throws IOException, JSONException
	{
		checkForDuplicateSurovina();
		
		if(nazevSurovina.getText() != null  && mnozstviSuroviny.getText() != null && !checkForDuplicateSurovina()) 
		{	
			sklad.put("nazev", nazevSurovina.getText());
			sklad.put("mnozstvi", Float.parseFloat(mnozstviSuroviny.getText()));
			
			fileManager.writeSklad(sklad);
			fileManager.getSklad();
			backToSklad();
		}
		else 
		{
			errorUdaje.setText("Musíš vyplnit potřebné údaje");
		}
	}
	
	
	public boolean checkForDuplicateSurovina()
	{
		ObservableList<Sklad> sklad = fileManager.getSklad();
		
		for(int i = 0; i < sklad.size(); i++) 
		{
			if (sklad.get(i).getNazev().toLowerCase().equals(nazevSurovina.getText().toLowerCase().trim().replaceAll(" +", " ")))
			{
				errorNazevSurovina.setText("Název suroviny již existuje");
				return true;
			}
		}
		
		errorNazevSurovina.setText(null);
		return false;
	}
	
	public void backToSklad() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Sklad.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (skladNovyPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}	
	

}