package com.github.Unbearables.kuchyn.process;

import java.util.List;

public class Sklad {

	private String nazev;
	private float mnozstvi;
	
	public Sklad(String nazev, float mnozstvi)
	{
		this.nazev = nazev;
		this.mnozstvi = mnozstvi;
	}
	
	public String getNazev() 
	{
		return nazev;
	}
	
	public float getMnozstvi() 
	{
		return mnozstvi;
	}
	
	public String toString() 
	{
		return nazev;
	}
	
}
