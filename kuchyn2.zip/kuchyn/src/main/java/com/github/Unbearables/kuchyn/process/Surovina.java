package com.github.Unbearables.kuchyn.process;

public class Surovina {

	private String nazev;
	private String jednotka;
	private float cena;
	private int alergen;
	private float mnozstvi;
	
	public Surovina(String nazev, String jednotka) 
	{
		this.nazev = nazev;
		this.jednotka = jednotka;
	}
	
	public float getMnozstvi() 
	{
		return mnozstvi;
	}
	
	public void setMnozstvi(float mnozstviSur) 
	{
		mnozstvi = mnozstviSur;
	}
	
	public void addMnozstvi(float mnozToAdd) 
	{
		mnozstvi += mnozToAdd;
	}
	
	public String getNazev() 
	{
		return nazev;
	}
	
	public String getJednotka() 
	{
		return jednotka;
	}
		
	public float getCena()
	{
		return cena;
	}
	
	public int getAlergen()
	{
		return alergen;
	}
	
	public String toString() 
	{
		return nazev;
	}
}
