package com.github.Unbearables.kuchyn.main;

import com.github.Unbearables.kuchyn.ui.MainWindowController;
import com.github.Unbearables.kuchyn.ui.FirstStartController;
import com.github.Unbearables.kuchyn.process.FileManager;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Start extends Application
{
	public static FileManager fileManager;
	
	public static void main(String[] args)
    {    	
		launch(args);        
    }
    
    /**
	 * Metoda, ve kter� se konstruuje okno, kontroler a hra,
	 * kter� se p�ed�v� kontroleru
	 */
	@Override
	public void start(Stage primaryStage) throws Exception 
	{		
		FileManager fileMngr = new FileManager();
		fileManager = fileMngr;
		fileManager.initialize();
		
		if(fileMngr.getFirstStart()) 
		{
			//form
			FXMLLoader loader = new FXMLLoader();
	    	loader.setLocation(getClass().getResource("/Kuchyn_FirstStart.fxml"));    	
	    	Parent root = loader.load();

	    	FirstStartController controller = loader.getController();
	    	
			
			primaryStage.setScene(new Scene(root));
			primaryStage.show();
			primaryStage.setTitle("Kuchyne");
		}
		else 
		{			
			FXMLLoader loader = new FXMLLoader();
	    	loader.setLocation(getClass().getResource("/Kuchyn_MainWindow.fxml"));
	    	Parent root = loader.load();

	    	MainWindowController controller = loader.getController();
	    	
			primaryStage.setScene(new Scene(root));
			primaryStage.show();
			primaryStage.setTitle("Kuchyne");
		}
	}	
}